def suma_2(a, b):
    return a + b

def resta_2(a, b):
    return a - b

x = 2